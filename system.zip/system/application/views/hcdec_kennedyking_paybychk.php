<div class="contentBox">
	<div style='float: right; margin-right: 12px'>
		<img src="/images/kkBannerSmallerStill.jpg">
	</div>
	<div style='font-family: Helvetica, Arial, Sans-serif; font-size: 14pt'>
		<strong>Your Selection</strong>
	</div>
	<p />
	<?php
	echo $selections['ticketHolderName']."<br>";
	echo $selections['ticketHolderEmail']."<br>";
	echo $selections['ticketHolderPhone']."<p/>";
	echo "Total: \$".sprintf("%.2f", $selections['ticketHolderInvoiceTotal']);
	echo "<p/>";
	?>
	<p />
	Please make checks payable to
	<p />
	Hillsborough County Democratic Party<br> P.O. Box 17158<br> Tampa, FL
	33682 
	<p />
	Tickets purchased by September 18 will be mailed. Thereafter, tickets
	will be available at the Will Call table the night of the event.
	Seating will be assigned based on the order in which the reservation
	was received.<br> Tickets are available by reservation only.
	<p />

	To learn more about sponsorship opportunities, print deadlines and ad
	specifications please contact:<br> Matt Isenhower at
	misenhower@hillsdems.org
	<p />
	<span
		style='font-family: Helvetica, Arial, Sans-serif; font-size: 11pt'> <em>Paid
			for by the Hillsborough County Democratic Party and not authorized by
			any federal candidate or candidate's committee. Corporate
			contributions accepted. Contributions are not tax deductible for
			federal or state income tax purposes.</em> </span>
</div>

<p />
</div>
