<?php
echo "Volunteer Coordinator:\r\n\r\n";
foreach( $volunteer as $key=>$value )
{
	echo "$key = \"$value\"\r\n";
}