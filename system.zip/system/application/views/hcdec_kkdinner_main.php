<div class="contentBox">
	<div style='float: left; margin-right: 12px'>
		<img src="/images/kkBannerSmaller.jpg">
	</div>

	<div style='font-family: Helvetica, Arial, Sans-serif; font-size:14pt'>
	<div style='color:darkblue;font-weight:bold;text-align:center'>
		Highlights coming soon
	<div style='height:4px'> </div>
	</div>
	
</div>
