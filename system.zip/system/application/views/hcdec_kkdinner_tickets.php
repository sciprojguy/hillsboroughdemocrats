<div class="contentBox">
<div style='float:left;margin-right:12px'>
<img src="/images/Kennedy King web.jpg">
</div>
<div style='font-family:Helvetica,Arial,Sans-serif;font-size:16pt;font-weight:bold;text-align:center'>
Tickets
</div>
<div style='float:left'>
<table style='width:400px;font-family:Helvetica,Arial,Sans-serif;font-size:12pt'>
<tr>
<td>Individual</td>
<td style='text-align:right'>$125</td>
</tr>
<tr>
<td>Host (includes two tickets to the dinner and special speakers reception)<br></td>
<td style='text-align:right'>$500</td>
</tr>
<tr>
<td>Students</td>
<td style='text-align:right'>$75</td>
</tr>
</table>
<p/>
If you prefer to pay by check please make the instrument payable to<p/>
<strong>
Hillsborough County Democratic Party <br>
P.O. Box 152164 <br>
Tampa, FL 33684-2164<p/>
</strong>
For more information contact: <br>
<strong>
Matt Eisenhower
</strong>
 at 
<strong>
 <a href="mailto:meisenhower@hillsdems.org">meisenhower@hillsdems.org</a>
</strong>
<p/>

Tickets will be distributed at the door of the event.<br>
Tickets are available by reservation only.
<p/>
<p/>
<p/>
</div>
<div style='clear:both'></div>
<div style='font-family:Helvetica,Arial,Sans-serif;font-size:11pt;margin-top:16px'>
<em>Paid for by the Hillsborough County Democratic Party and not authorized by any federal candidate or candidate's committee. Corporate contributions accepted. Contributions are not tax deductible for federal or state income tax purposes.</em>
</div>
</div>