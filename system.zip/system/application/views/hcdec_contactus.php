<?php
?>
<div class="contentBox">
		  <table width="100%" border="0" cellpadding="0" cellspacing="5">
		  	<tr>
		  		<td align=center>
			<img src="/images/hcdeclogo.jpg">
		  		</td>
		  	</tr>
		    <tr>
		      <td>
		        <table width="75%" border="0" align="center" cellpadding="0" cellspacing="5">
		        <tr>
		          <td width="98%" height="170">The Hillsborough Democratic Party Mailing Address is:<p/>
		              <strong>HCDEC<br>
		              PO Box 272488<br>
		              Tampa, FL 33618<br>
		              </strong>
		            <p/>		            
		            </strong>
The Hillsborough County Executive Committee meets every month at the 
CHILDREN'S BOARD, 1002 E. Palm Avenue, Tampa, Florida.  
		            Check out our<a href="/hcdec/calendar"> calendar&nbsp;</a>for details.&nbsp;
		            <ul>
		              <li>
		                <div>To contact the <strong>Chair</strong> of the Hillsborough County Democratic Executive Committee: <a href="mailto:cmitchell1384@yahoo.com" target="_blank">chair@hillsdems.org</a>		              </div>
		              </li>
		            </ul>
		            <ul>
		              <li>
	                  <p>For problems about the website or if you are unable to log in as a member, please contact the Webmaster: <a href="mailto:info@hillsdems.org" target="_blank">info@hillsdems.org</a></p>
	                  </li>
	                <li>
To suggest events or news for our website contact <a href="mailto:help@hillsdems.org">help@hillsdems.org</a>.<p/>
<li>For Press Inquiries please contact <a href="mailto:help@hillsdems.org">help@hillsdems.org</a></li>
	                </ul>
		            </td>
	            </tr>
	          </table>
	          <br></td>
	        </tr>
	    </table>
</div>