<tr>
	<td colspan=2 width=100%>
		<!--
		what goes in here?
		
		Mission statement
		List of our principles
		Link to our platform
		Link to our committees
		List of our officers (with pix)
		When our next meeting is
		
		+-------------------------------------------------+
		| date/time link to next meeting                  |
		| +--------------------+  +---------------------+ |
		| | our principles     |  | our mission         | |
		| |                    |  |                     | |
		| | link to platform   |  |                     | |
		| +--------------------+  +---------------------+ |
		| +--------------------+  +---------------------+ |
		| | our officers       |  | our committees      | |
		| |                    |  |                     | |
		| |                    |  |                     | |
		| +--------------------+  +---------------------+ |
		| link to our bylaws                              |
		+-------------------------------------------------+
		
		  -->
	</td>
</tr>