<div class="contentBox">
<a href="/pdf/HCDEC Bylaws Changes06-4-12.pdf">Proposed HCDEC Bylaws 2012</a>
</div>