<div class="contentBox">
<img src="/images/Slate Card.jpg" style='float:left'>
<div style='height:100%;width:60%;float:left;padding-left:16px'>
More Information from Democratic and Non-Partisan Sources<br>
<ul>
	<li><a href="http://www.dailykos.com/story/2012/09/06/1128093/-President-Obama-s-Accomplishments-So-Far">President Obama's Accomplishments</a></li>
	<li><a href="http://billnelson.senate.gov/about/biography.cfm">Senator Bill Nelson's Accomplishments</a></li>
	<li><a href="http://www.progressivedemcaucusfl.org/pdfs/DPCF-2012-Ballot-Amendment-Positions2-7-31-12.pdf">Florida Progressive Democratic Caucus' Overview of the Ballot Amendments</a></li>
	<li><a href="http://www.thefloridavoter.org/resources/issues/2012-constitutional-amendments">League of Women Voters (nonpartisan) Analysis of the Amendments</a>
		(If you like the League's information, check out their <a href="http://thefloridavoter.org/files/download/453">Voter Guide</a> covering statewide races, judges, and more.)</li>
	<li><a href="http://www.wmnf.org/archives?date=2012-10-02&program_id=396">Audio download</a> of former Hillsborough County Democratic Party Chair Pat Kemp and Florida Progressive Caucus Chair Susan Smith discussing the Amendments on WMNF
	</li>
</ul>
</div>
</div>