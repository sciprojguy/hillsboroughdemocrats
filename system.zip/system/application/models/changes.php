<?php
class Changes extends Model {

	function Changes()
	{
		parent::Model();
	}

	function addChange( $userid, $table, $changes )
	{
		
	}
	
	function listChangesForUser( $userid )
	{
		
	}
	
	function listChangesForStatus( $status )
	{
		
	}
}