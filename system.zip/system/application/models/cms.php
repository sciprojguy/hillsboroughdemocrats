<?php

class Cms extends Model {

	function Cms()
	{
		parent::Model();
	}
	
	function getContentForPage( $pagename )
	{
		
	}
	
	function setContentForPage( $content, $pagename )
	{
	}
}