<?php
	# requires, as input:
	#
	# 0. $pagename (done)
	# 1. $user (done)
	# 2. $tickerItems (not done)
	# 3. $submenuItems (not done)
	# 4. $mainContent (not done)
	# 5. $rightItems (not done)
	
	$identityContent = "";
	if(isset($user['id']))
	{
		$identityContent = "<div style='width:200px;font-family:Helvetica,Arial,sans-serif;font-size:9pt;color:white'>";
		if(isset($user['salutation']) && !empty($user['salutation']))
			$identityContent .= "Welcome, {$user['salutation']} &#149; ";
		else
			$identityContent .= "Welcome, {$user['firstName']} {$user['lastName']} &#149; ";
		$identityContent .= "<a style='font-family:Helvetica;font-size:9pt;color:white;text-decoration:none;' href=\"/hcdec/logout\">Logout</a>";
		$identityContent .= "</div>";
	}
	else
	{
		$identityContent = "<div style='width:200px;font-family:Helvetica,Arial,sans-serif;font-size:9pt;color:white'>";
		$identityContent .= "<form method=POST action=/hcdec/login>";
		$identityContent .= "Username: <input type=text name=username size=20><br>";
		$identityContent .= "Password: <input type=password name=password size=20>&nbsp;<button type=submit style='width:60px;font-size:9pt'Log In>Log In</button>";
#		$identityContent = "<a style='font-family:Helvetica;font-size:9pt;color:white;text-decoration:none;' href=\"/hcdec/login\">Member login</a>";
		$identityContent .= "</form>";
		$identityContent .= "</div>";
	}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>Hillsborough County Democratic Party</title>
	<link rel="stylesheet" media="screen" type="text/css" href="http://test.local/css/test.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="http://test.local/css/site.css" />
	<!-- for JS calendar -->
	<link rel="stylesheet" type="text/css" href="/js/tcal.css" />
	<script type="text/javascript" src="/js/tcal.js"></script> 
	<SCRIPT LANGUAGE="JavaScript" SRC="/js/timepicker.js"></SCRIPT>
</head>
<body style='background-color:black'>

<div class="pageContainer">

	<div class="header">
	
		<div style='width:75%;float:left;align:left'>
			<img src="/images/banner.png">
		</div>
		
		<div style='width:25%;float:left;align:right;text-align:right'>
			<a href="http://eepurl.com/g7pxU"><img src="/images/signupButton.png"></a><br>
			<?= $identityContent ?>
		</div>
		
	</div>
	<?php
		$this->load->model('alerts');
		$alerts = $this->alerts->getCurrentAlerts();
		if(count($alerts)>0)
		{
			$tickerContentArray = array();
			foreach($alerts as $alert) 
			{
				$shortTitle = $alert['short_title'];
				$actionURL = $alert['action_url'];
				$tickerContentArray[] = "<a class=\"tickerLink\" href=\"$actionURL\">$shortTitle</a>";
			}
			$tickerContentHTML = implode(" &#149; ", $tickerContentArray);
	 ?>
	<table width=960px border=0 cellpadding=0>
	<tr><td width=100%>
	<div ID="TICKER" STYLE="overflow:hidden; background-color:lightblue; margin-bottom:4px; padding-top:0; height:24px;width:960px;"  onmouseover="TICKER_PAUSED=true" onmouseout="TICKER_PAUSED=false">
		<?php echo $tickerContentHTML ?>
	</div>
	<?php
		}
	?>
	<script type="text/javascript" src="/js/webticker_lib.js"></script>
	</td></tr>
	</table>
	<div style='height:8px'></div>
	
	<div class="menu">
		<a href="/hcdec/index" class="menuItem" id="index" title="Home page">Home</a> 
		<a href="/hcdec/aboutus" class="menuItem" id="aboutus" title="Officers, Committees, Principles and Platform">About Us</a> 
		<a href="/hcdec/candidates" class="menuItem" id="candidates">Candidates</a> 
		<a href="/hcdec/officials" class="menuItem" id="officials">Officials</a> 
		<a href="/hcdec/clubsandcaucuses" class="menuItem" id="clubsandcaucuses">Clubs &amp; Caucuses</a> 
		<a href="/hcdec/resources" class="menuItem" id="resources">Resources</a> 
		<a href="/hcdec/news" class="menuItem" id="news">News</a> 
		<a href="/hcdec/contactus" class="menuItem" id="contactus">Contact Us</a> 
	<?php 
		if(isset($user['id']))
		{
		?>
		<a href="/hcdec/myhcdec" class="menuItem" id="myhcdec">My HCDEC</a> 
	<?php
		 } 
		?>
	</div>
	
	<div class="leftColumn">
	<!--{SUBMENU}-->
	</div>
	<div class="contentBoxContainer">
	<div class="mainColumn">
	<?= $content ?>
	</div>
	</div>
	<div class="rightColumn">
	<!--{RIGHTITEMS}-->
	</div>
	<div class="footer">
	<!--{FOOTER}-->
	</div>
	
</div>
</body>
</html>