<?php
?>
<div class="contentBox">
		  <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="5">
		    <tr>
		      <td><br>
		        <br>
		        <table width="75%" border="0" align="center" cellpadding="0" cellspacing="5">
		        <tr>
		          <td width="98%" height="170"><strong>The Hillsborough Democratic Party Mailing Address is:</strong><br>
		            <blockquote dir="ltr">
		              <div>HCDEC</div>
		              <div>PO Box 152164</div>
		              <div>Tampa, FL 33684-2164&nbsp;&nbsp;&nbsp; </div>
	                </blockquote>
		            <strong><br>
		            </strong>The   Hillsborough County Executive Committee meets the 3rd Monday of every   month at the CHILDREN'S BOARD, 1002 E. Palm Avenue, Tampa, Florida, at   6:00pm to 8:00pm.&nbsp; Check out our<a href="/calendar/index.html"> calendar&nbsp;</a>for time and location.&nbsp;
		            <ul>
		              <li>
		                <div>To contact the <strong>Chair</strong> of the Hillsborough County Democratic Executive Committee: <a href="mailto:cmitchell1384@yahoo.com" target="_blank">chair@hillsdems.org</a>		              </div>
		              </li>
		            </ul>
		            <ul>
		              <li>
	                  <p>For problems about the website or if you are unable to log in as a member, please contact the Webmaster: <a href="mailto:info@hillsdems.org" target="_blank">info@hillsdems.org</a></p></li>
	                </ul>
		            </td>
	            </tr>
	          </table>
	          <br></td>
	        </tr>
	    </table>
</div>