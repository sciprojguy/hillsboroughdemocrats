<!--
 name
 description (if present)
 president (if present)
 meets (if present)
 contact phone (if present)
 contact email (if present)
 url (if present) 
  -->
<div class="clubOrCaucus">
	<strong><?= $name ?></strong><br>
	<?php
	if(isset($description) && !empty($description)) 
		echo "$description<br>"; 
	if(isset($meets) && !empty($meets)) 
		echo "<strong>Meets:</strong> $meets<br>"; 
	if(isset($president) && !empty($president)) 
		echo "<strong>President:</strong> $president<br>"; 
	if(isset($contact_phone) && !empty($contact_phone)) 
		echo "<strong>Phone:</strong>$contact_phone<br>"; 
	if(isset($contact_email) && !empty($contact_email)) 
		echo "<strong>Email:</strong> <a href=\"mailto:$contact_email\">$contact_email</a><br>"; 
	if(isset($club_url) && !empty($club_url)) 
		echo "<strong>Web Site:</strong> <a href=\"$club_url\">$club_url</a><br>"; 
	?>
</div>