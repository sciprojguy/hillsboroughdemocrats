		  <table width="100%" border="0" cellpadding="0" cellspacing="25" class="contentBox">
		    <tr>
		      <td colspan="3" valign="top"><img src="/images/ABOUTUS.jpg" width="356" height="43"><br>
		        <br>
		        The Democratic   Executive Committee (DEC) is the governing body of the Democratic Party in Hillsborough County. Chartered under the Florida Democratic Party (FDP), we are   charged with maintaining and building relationships between constituents in   Hillsborough County and their elected officials on local, state, and national   levels.
<p align="justify">Our membership is   composed of those Democratic individuals who seek active participation in the   decision-making process of the Democratic Party on a County level. Membership is   divided by precincts, with one man and one woman for every one thousand   registered Democrats in that precinct. These precincts committee people are   grouped into thirteen areas based upon the existing County Commission   Districts.</p>
                <p align="justify">Meetings are   held once per month, on the third Monday of the month.  </p>
              <p align="justify">Ultimately, our   goal is to create an increased Democratic presence throughout Hillsboroughe County.   By strengthening this Democratic foundation, we are able to recruit future   candidates, pursue Democratic ideals and initiatives, and most importantly win   elections on County, State, and National levels.&nbsp;&nbsp; <br>
                <br>
                <a href="/PlatformPrinciples2011.pdf">Principles for Hillsborough County Democratic Party Platform              </a></p></td>
	        </tr>
		    <tr>
		      <td height="240" valign="top"><p class="TITLEA"><u>STEERING COMMITTEE</u></p>
		        <p>Chair, <a href="MAILto:chair@hillsdems.org">Christopher Mitchell</a></p>
		        <p>Vice Chair, <a href="MAILto:vicechair@hillsdems.org">Sharon Carter</a></p>
		        <p>Treasure, <a href="MAILto:treasurer@hillsdems.org">Marilyn Cappiello</a></p>
		        <p>Secretary, <a href="MAILto:secretary@hillsdems.org">Ella Coffee</a></p>
		        <p>State Committeewoman, <a href="mailto:katlvr952@aol.com">Sally Phillips</a></p>
	          <p>State Committeeman, <a href="mailto:aclendenin@hotmail.com">Alan Clendenin</a></p></td>
		      <td valign="top"><p>&nbsp;</p>
		        <p>Affirmative Action, <a href="mailto:garciamati@yahoo.com">Matilda Garcia </a>&nbsp;</p>
                <p>Campaign and Precinct, Vacant<u></u><u></u></p>
                <p>Bylaws, <a href="mailto:seanmichaelshaw@gmail.com">Sean Shaw</a></p>
<p>Credentials, <a href="MAILto:credentials@hillsdems.org">Ercilia Albistu</a></p>
<p>Membership,<a href="MAILto:secretary@hillsdems.org"> Ella Coffee</a></p>
              <p>Finance, <a href="mailto:votestacyfrank1@gmail.com">Stacy Frank</a></p></td>
		      <td valign="top"><p>&nbsp;</p>
		        <p>Legislative Liaison,<a href="mailto:STSMITH222@aol.com"> Susan Smith</a></p>
                <p>Platform, <a href="mailto:awolfe1@tampabay.rr.com">Alvin Wolfe</a></p>
                <p>Publicity and Public Relations, <a href="mailto:kkos1423@gmail.com">Karleen Kos</a></p>
                <p>IT, <a href="MAILto:info@hillsdems.org">Daniel McMilan</a></p>
                <p>Legal, <a href="mailto:sharonsamek@verizon.net">Sharon Samek</a></p>
              <p>Labor, <a href="mailto:tim@fcan.org">Tim Heberlein</a></p></td>
	        </tr>
        </table>
