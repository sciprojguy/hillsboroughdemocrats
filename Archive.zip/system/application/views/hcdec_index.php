<div class='contentBox'>
<div style='width:64%;float:left;background-color:white'>
	<div style='width:100%;padding:4px 4px 4px 4px;'>
		<img style='border:2px;border-color:lightblue;margin-right:8px;margin-bottom:8px;' 
			src="/images/convention.jpg" width="275" height="118" align="left">
		<strong>2012 Democratic National Convention</strong>
		<p>
		The Road to the Convention starts in the Hillsborough County DEC!
		<br>
		<br>
		The Democratic National Convention is firmly held in American history as an historic event in the life of the nation. Nothing can compare to the thrill, excitement and exhilaration of witnessing our nation&rsquo;s Democratic leaders share their vision, ideas and passion with fellow Democrats from all over the United States.
		<br>
		<div style='width:100%;text-align:center;'>
		<a href="u=bbf641b7b3417d834ef8dd1dc&id=48d56c9772&e=5fee208d2e">LEARN MORE</a>
		</div>
	</div>
	
	<div style='width:100%;background-color:lightgray;height:2px;'></div>
	
	<div style='width:100%;padding:10px 10px 10px 10px'>
		<strong>
			<a href="http://www.voterfocus.com/hosting/hillsborough/ew_pages/Candidate Services/Precinct Committeemen and Women.pdf">
			PRECINCT COMMITTEEMEN &amp; COMMITTEEWOMEN Information
			</a>
		</strong>
	</div>
	
	<div style='width:100%;background-color:lightgray;height:3px'></div>
	
	<div style='width:100%;padding:10px 10px 10px 10px'>
		<strong class="headline">GET INVOLVED</strong>
		<br>
		<div style='float:left'>
		  <ol id="list">
			  <li><strong><u><a href="MAILto:credentials@hillsdems.org">BECOME A MEMBER</a></u></strong></li>
			  <li><strong><u><a href="mailto:volunteer@hillsdems.org">VOLUNTEER</a></u></strong></li>
			  <li><strong><u><a href="http://votehillsborough.org/?id=3">FIND YOUR PRECINCT</a></u></strong></li>
			  <li><strong><u><a href="http://www.voterfocus.com/hosting/hillsborough/?urllength=5000&showurl=https%3A//www.voterfocus.com/ws/Pfinder/printvapp4.php?county=hillsborough">REGISTER TO VOTE</a></u></strong></li>
		  </ol>
		</div>
		<div style='float:right;margin-right:20px;'>
			<a href="http://www.floridaplatform.com/" target="_blank"><strong>Take the Florida Platform Survey!</strong></a>
		</div>
		<div style='clear:both'></div>
    </div>
	
	<div style='width:100%;background-color:lightgray;height:3px'></div>

	<div>
		<a href="http://us1.campaign-archive2.com/?u=bbf641b7b3417d834ef8dd1dc&id=48d56c9772&e=5fee208d2e">1.22.2012 - 
		<u><strong>LATEST NEWS </strong>from the Hillsborough Democratic Party</u>
		</a>
	</div>
	
	<div style='width:100%;background-color:lightgray;height:3px'></div>

</div>

<div style='float:right;width:35%; height:100%; background-color:white;'>
	
	<!-- spacer div -->
	<div style='height:4px'></div>
	
	<!-- volunteer link -->
		<div style='width:299px;margin-left:auto;margin-right:auto'>
			<a href="/hcdec/volunteer">
			<img src="/images/volunteer.png" width="299" height="40" border="0">
			</a>
		</div>
		
	<!-- spacer div -->
	<div style='height:16px'></div>

	<!-- donate link -->
		<div style='width:299px;margin-left:auto;margin-right:auto'>
			<form action="https://Simplecheckout.authorize.net/payment/CatalogPayment.aspx" 
				method="post" name="form1" target="_blank">
			  <input type="hidden" name ="LinkId" value ="dd7e22ac-1d8a-4b17-9340-12f3a0050027" />
			  <input type="image" name="imageField" id="imageField" src="/images/donateButton.png">
			</form>
		</div>
		
	<!-- spacer div -->
	<div style='height:16px'></div>
	
	<!-- Google calendar -->
	<div style='width:100%;height:379;margin-left:auto;margin-right:auto;'>
	<!-- 
		<iframe src="https://www.google.com/calendar/embed?title=Upcoming+Events&amp;showPrint=0&amp;showTabs=0&amp;showTz=0&amp;mode=AGENDA&amp;height=250&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;src=emailhillsdems%40gmail.com&amp;color=%23182C57&amp;ctz=America%2FNew_York" style=" border-width:0 " width="100%" height="250" frameborder="0" scrolling="no"></iframe>
		<p>
		<!-- link to full page calendar -->
		 -->
		<div style='text-align:center;width:100%;'>
		<a href="/hcdec/calendar">Full	Calendar &gt;&gt;&gt;</a>
		</div> 
	</div>

	<!-- Facebook etc links -->
	<a href="https://www.facebook.com/pages/Hillsborough-County-Democratic-Party/134328246608491"><img border=0 src="/images/Facebook-Logo-32x32.png"></a>
	&nbsp;
	<a href="https://twitter.com/#!/hillsdems"><img border=0 src="/images/twitter_logo.png"></a>
</div>

<div style='clear:both;height:16px;width:100%;background-color:white;'>
</div>

</div>