	<tr>
		<td colspan=2 width="100%" bgcolor="#E1E1E1" valign=top>
			<!--
			add link that takes you to the boxitem.php form.
			list of box items, each with Edit / Delete links.  if you can see this page you can see those controls.
			  -->
		<?php
			$this->load->model('boxitems');
		 ?>
		</td>
	</tr>
	

