<div>
<?php
$roles = $user['roles'];
foreach($roles as $role) echo "$role<br>";
if(in_array('manage_candidates', $user['roles']))
{
	echo "<a style='color:white' href=\"/hcdec/newcandidate\">Add Candidate</a>";
}

/*
 * ideally this should display a bunch of tabs, one for each office level.  that
 * means one container DIV per office level, and in each DIV there are the offices
 * with candidates in them.
 */
# foreach( $office_levels as $office_level )
# {
#	echo a header - President, Federal, State, County, Local
#	foreach( $candidates[$office_level] as $candidate )
#	{
#		loop thru and echo the <div> for each candidate.  if user can
#		manage candidates, add an "Edit" link in the <div>
/*
 * 		height  width
 * 		320px x 300px 
 		+-------------------+
 		| office title      |
 		| name              |
 		| picture           |
 		| statue ON date    |
 		| contact link      |
 		|            [edit] |
 		+-------------------+
 		
 		3 per row and they float left
 		<div style='float:left;width:300px'>
 			
 		</div>
 */
#	}
# }
#

?>
</div>