<div class='calendarBox'>
<!--
calendar page will include links for members to submit a calendar event
and to subscribe to tagged events. the "submit event" form will include
a place to tag the event and to make the event recurring - "third monday 
of every month", e.g.

the event gets created and an email goes to the person who approves it.
someone is in charge of the calendar.

1. month and year are taken from the URI
2. day of week of first day of month is calculated
3. blank squares are generated from day of week 1 to the dow
4. then we start generating calendar squares.

before we do this, we look up all of the approved events that are in 
that month and year and accumulate them by day of the month in an
associative array whose carried value is an array of events in order
of start time. Then, in each cell, we can list up to N things scheduled
for that day.
-->
<?php
 $cellWidth = 1020/7;
 $first_day = mktime(0,0,0,$month, 1, $year) ; 
 $title = date('F', $first_day) ; 
 $day_of_week = date('D', $first_day) ; 
 switch($day_of_week){ 
	case "Sun": $blank = 0; break; 
 	case "Mon": $blank = 1; break; 
	case "Tue": $blank = 2; break; 
	case "Wed": $blank = 3; break; 
	case "Thu": $blank = 4; break; 
	case "Fri": $blank = 5; break; 
	case "Sat": $blank = 6; break; 
 }
 
 $days_in_month = cal_days_in_month(0, $month, $year) ;
  
 echo "<table border=0 width=100% height=100% cellpadding=0 cellspacing=0>";
 echo "<tr><td colspan=7><div style='font-family:Helvetica,Arial,Sans-serif;font-weight:bold;text-align:center'>$title $year</div> </td></tr>";
 echo "<tr>
 	<td width=$cellWidth align=center>Sun</td>
 	<td width=$cellWidth align=center>Mon</td>
 	<td width=$cellWidth align=center>Tue</td>
 	<td width=$cellWidth align=center>Wed</td>
 	<td width=$cellWidth align=center>Thu</td>
 	<td width=$cellWidth align=center>Fri</td>
 	<td width=$cellWidth align=center>Sat</td>
 	</tr>";
 $day_count = 1;
 echo "<tr>";
 while ( $blank > 0 ) 
 { 
 	echo "<td width=$cellWidth height=90>
 		<div style='border:1px solid lightgray;width:$cellWidth; height:100%;'></div>
 	</td>"; 
 	$blank = $blank-1; 
 	$day_count++;
 }
  
 //sets the first day of the month to 1 
 $day_num = 1;
 
 //count up the days, untill we've done all of them in the month
 while ( $day_num <= $days_in_month ) 
 {
 	// get $events[$day_num] -> formatted for calendar day
 	// we can also add "special days" like MLK day 
	echo "<td width=$cellWidth height=100 valign=top>
	<div style='border:1px solid lightgray;width:$cellWidth; height:100%;'>
	<div style='width:100%;font-family:Helvetica,Arial,Sans-serif;text-align:right;padding-right:15px;'>
		$day_num &nbsp;
	</div>";
	echo "<div style='height:1px;background-color:lightgray;width:90%;margin-left:auto;margin-right:auto'> </div>";
	echo "<div style='height:92px;width:100%;overflow:auto;'>";
 	if(isset($events[$day_num]))
 	{
 		foreach($events[$day_num] as $event)
 		{
 			echo "<div style='font-family:Helvetica,Arial,Sans-serif;font-size:8pt;padding-left:2px;'>{$event['title']}</div>";
 		}
 	}
 	echo "</div>";
 	
	echo "</div>";
	echo "</td>"; 
	$day_num++; 
 	$day_count++;

	//Make sure we start a new row every week

	if ($day_count > 7)
	{
		echo "</tr><tr>";
		$day_count = 1;
 	}

 }
  
	while ( $day_count >1 && $day_count <=7 ) 
	{ 
		echo "<td width=130 height=90 align=right valign=top> </td>"; 
		$day_count++; 
	} 

echo "</tr></table>"
?>

<!-- 
	  <iframe 
	  	src="https://www.google.com/calendar/embed?title=Upcoming+Events&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;src=emailhillsdems%40gmail.com&amp;color=%23182C57&amp;ctz=America%2FNew_York" style=" border-width:0 " width="100%" height="600" frameborder="0" scrolling="no">
	  </iframe>
 -->
 </div>