<!DOCTYPE html>
<html>
<head>
	<title><?=$title?></title>
	<!-- include JS and CSS here -->
</head>
<body>