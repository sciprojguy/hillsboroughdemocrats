<div class="boxContainer">
	<div class="boxTitle">
		<?php echo $title ?>
	</div>
	<div class="boxPicture">
		<img class="boxPicture" src="/images/<?php echo $picture?>">
	</div>
	<div class="boxLead">
		<?php echo $lead ?>
	</div>
	<div class="boxMore">
		<a class="boxMoreLink" href="<?php echo "/home/article/$id"?>">more...</a>
	</div>
</div>