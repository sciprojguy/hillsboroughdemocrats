<tr>
	<td colspan=2 width=100%>
		<!--
		what goes in here?
		
		list of clubs (alphabetical)
		in each row...
			name
			*short* description
			next mtg date/time/loc
			
		list of caucuses (alphabetical)
			name
			*short* description
			next mtg date/time/loc
		
		+-------------------------------------------------+
		| clubs                   caucuses                |
		| +--------------------+  +---------------------+ |
		| |                    |  |                     | |
		| |                    |  |                     | |
		| |                    |  |                     | |
		| |                    |  |                     | |
		| +--------------------+  +---------------------+ |
		|                                                 |
		+-------------------------------------------------+
		
		  -->
	</td>
</tr>