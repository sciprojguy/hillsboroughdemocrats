<?php
	$this->load->model('member');
	$types = $this->member->memberTypes();
	$statuses = $this->member->statusValues();
	
	$typeMenu = form_dropdown('type', $types, $memberInfo['type'], $memberInfo['type']);
	$statusMenu = form_dropdown('status', $statuses, $memberInfo['status'], $memberInfo['status']);
	
	$dobDateField = form_input( array(
		'id'=>'dob',
		'name'=>'dob',
		'size'=>10,
		'value'=>$memberInfo['dob'],
		'class'=>'tcal'
	) );
	
	$termBeganDateField = form_input( array(
		'id'=>'term_began',
		'name'=>'term_began',
		'size'=>10,
		'value'=>$memberInfo['term_began'],
		'class'=>'tcal'
	) );
	
	$statusDateField = form_input( array(
		'id'=>'status_date',
		'name'=>'status_date',
		'size'=>10,
		'value'=>$memberInfo['status_date'],
		'class'=>'tcal'
	) );
	
	$firstNameField = form_input( array(
		'id'=>'firstName',
		'name'=>'firstName',
		'size'=>20,
		'maxlength'=>32,
		'value'=>$memberInfo['firstName']
	) );
	
	$middleNameField = form_input( array(
		'id'=>'middleName',
		'name'=>'middleName',
		'size'=>20,
		'maxlength'=>32,
		'value'=>$memberInfo['firstName']
	) );
	
	$lastNameField = form_input( array(
		'id'=>'lastName',
		'name'=>'lastName',
		'size'=>32,
		'maxlength'=>48,
		'value'=>$memberInfo['lastName']
	) );
	
	$salutationField = form_input( array(
		'id'=>'salutation',
		'name'=>'salutation',
		'size'=>32,
		'maxlength'=>32,
		'value'=>$memberInfo['salutation']
	) );

	$precinctField = form_input( array(
		'id'=>'precinct',
		'name'=>'precinct',
		'size'=>6,
		'maxlength'=>6,
		'value'=>$memberInfo['precinct']
	) );
	
	$streetField = form_input( array(
		'id'=>'street',
		'name'=>'street',
		'size'=>32,
		'maxlength'=>32,
		'value'=>$memberInfo['street']
	) );
	
	$cityField = form_input( array(
		'id'=>'city',
		'name'=>'city',
		'size'=>32,
		'maxlength'=>32,
		'value'=>$memberInfo['city']
	) );
	
	$stateField = form_input( array(
		'id'=>'state',
		'name'=>'state',
		'size'=>3,
		'maxlength'=>3,
		'value'=>$memberInfo['state']
	) );
	
	$zipField = form_input( array(
		'id'=>'zip',
		'name'=>'zip',
		'size'=>10,
		'maxlength'=>10,
		'value'=>$memberInfo['zip']
	) );
	
	$emailField = form_input( array(
		'id'=>'email',
		'name'=>'email',
		'size'=>60,
		'maxlength'=>255,
		'value'=>$memberInfo['email']
	) );
	
 ?>
<tr>
<td colspan=2>

	<!--
		form goes in here.  can make it do multiple duty:
		
		1. for ercilia, all fields show up.  has "edit_all_members" role.
		2. for member, all their own fields are editable. has "edit_own_profile".
			if address changes, they need to go look up their precinct (or we can do
			it for them using the SOE web site?)
		
		<type> <status>
		[precinct]
		[firstname] [middlename] [lastname] 
		[salutation]
		[street]
		[city] [state] [zip]
		[email] 
		[phone]
		
		[notes]
		
		$action is set in the controller. note - this will need to be
		done thru the /admin controller.  people who want to be members
		will still need to download a PDF doc or get a printed copy, fill
		it out, and send it to Credentials.  Someone in Credentials will
		do the admin task, which will create the record and generate a
		token to send to the email address on the form.  The recipient
		will then click on the link, which will send them to 
		
			/admin/reviewprofile/<tokenvalue>
		
		at which point they can edit their profile info and set a password.
		
		That creates the row in 'users' and ties the user row to their member
		info.
	  -->
	  
	  <form method=POST action="<?=$action?>">
	  	Type: <?=$typeMenu?><br>
	  	Status: <?=$statusMenu?><br>
		Precinct: <?=$precinctField?><br>
		First: <?=$firstNameField?><br>
		Middle: <?=$middleNameField?><br>
		Last: <?=$lastNameField?><br>
		Salutation: <?=$salutationField?><br>
		Street: <?=$streetField?><br>
		City: <?=$cityField?><br>
		Zip: <?=$zipField?><br>
		Phone: <?=$phoneField?><br>
		Email: <?=$emailField?><br>
		Term Began: <?=$termBeganField?><br>
		<input type=reset value=" Clear ">&nbsp;<input type=submit value=" Apply ">	
	  </form>
</td>
</tr>