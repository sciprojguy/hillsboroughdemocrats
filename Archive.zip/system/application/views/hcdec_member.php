<!--

Member page will contain submenu links down the side - 

1. link to edit member profile (put this in welcome div)

2. box of subscribed events

3. box of incoming unread messages

4. box of action items (tasks)

5. submenu? depending on roles assigned to user:
	Manage Users | Manage Members | Manage Alerts | Edit Newsletter | Email Blast
	
(In header, also should have breadcrumb links across the top.  Means I should be keeping a breadcrumb
stack in the $_SESSION with each page change?  Format:

	Main Section > Subsection
	Main Section > Other Page
)


 -->
 
<tr>
	<td colspan=2 width="100%">
	<table border=0 cellpadding=2 width=100%>
		<tr>
			<td width=20% valign=top>
			<!-- nav links go here -->
			<?php
				# check the assigned roles to populate the left-hand nav menu.
				# REFACTOR - move these into their own model class to take
				# roles and generate an array of links and labels.
				if(isset($user['roles']))
				{
					$navMenu = "<br><span style='color:lightblue;font-family:Helvetica,Arial,sans-serif;'>Navigation</span><br><br>";
					$roles = $user['roles'];
					if(in_array('manage_alerts',$roles))
						$navMenu .= anchor( "/hcdec/alerts", "Manage Alerts", "style='color:white;font-family:Helvetica,Arial,sans-serif;' class='plainLink'" )."<br>";				
					if(in_array('manage_events',$roles))
						$navMenu .= anchor( "/hcdec/events", "Manage Calendar", "style='color:white;font-family:Helvetica,Arial,sans-serif;' class='plainLink'" )."<br>";
					if(in_array('manage_users',$roles))
						$navMenu .= anchor( "/hcdec/users", "Manage Users", "style='color:white;font-family:Helvetica,Arial,sans-serif;' class='plainLink'" )."<br>";
					if(in_array('manage_members',$roles))
						$navMenu .= anchor( "/hcdec/members", "Manage Members", "style='color:white;font-family:Helvetica,Arial,sans-serif;' class='plainLink'" )."<br>";
					if(in_array('manage_candidates',$roles))
						$navMenu .= anchor( "/hcdec/candidates", "Manage Candidates", "style='color:white;font-family:Helvetica,Arial,sans-serif;' class='plainLink'" )."<br>";
					if(in_array('manage_officials',$roles))
						$navMenu .= anchor( "/hcdec/officials", "Manage Officials", "style='color:white;font-family:Helvetica,Arial,sans-serif;' class='plainLink'" )."<br>";
					if(in_array('edit_newsletter',$roles))
						$navMenu .= anchor( "/hcdec/newsletter", "Edit Newsletter", "style='color:white;font-family:Helvetica,Arial,sans-serif;' class='plainLink'" )."<br>";
						
					$navMenu .= "<div style='height:1px;width:100%;background-color:lightgray'></div>";
					$navMenu .= anchor("/hcdec/submitevent", "Submit Calendar Event", "style='color:white;font-family:Helvetica,Arial,sans-serif;' class='plainLink'" )."<br>";
					
					echo $navMenu;
				}
			 ?>
			</td>
			<td width=40% valign=top>
				<?php 
					$boxParams['events'] = $events;
					$this->load->view('eventsbox', $boxParams);
				?>
			</td>
			<td width=40% valign=top>
			<!-- messages -->
				<?php 
					$boxParams['messages'] = array();
					$this->load->view('messagesbox', $boxParams);
				?>
			</td>
		</tr>
	</table>
	</td>
</tr>