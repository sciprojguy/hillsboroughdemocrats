<!-- this page just lists the users - username, first/middle/last, status, edit link -->
<p>Users page for HCDEC Admin Tool<p>
<table border=0 cellpadding=4 width=100%>
<?php 
foreach( $users as $user )
{
	echo "<tr>";
	echo "<td>{$user['id']}</td>";
	echo "<td>{$user['member_id']}</td>";
	echo "<td>{$user['userType']}</td>";
	echo "<td>{$user['status']}</td>";
	echo "<td>{$user['username']}</td>";
	echo "<td>{$user['firstName']} {$user['middleName']} {$user['lastName']}</td>";
	echo "</tr>";
}
?>
</table>