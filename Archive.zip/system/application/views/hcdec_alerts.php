<tr>
	<td colspan=2 style='background-color:#888888'>
	<table border=0 cellpadding=4 width=100%>
	<?php
	// if($perms['add_alerts'])
	echo "<tr><td colspan=6><a href=\"/admin/addalert\">Add Action Alert</a><p></td></tr>";
	foreach($alerts as $alert)
	{
		echo "<tr>";
		// id
		// type
		echo "<td colspan=2>{$alert['type']}</td>";
		// short_title
		echo "<td><a href=\"/home/alert/{$alert['id']}\">{$alert['short_title']}</a></td>";
		// action_url
		// start_date_time
		echo "<td>{$alert['start_date_time']}</td>";
		// end_date_time
		echo "<td>{$alert['end_date_time']}</td>";
		// status
		echo "<td>{$alert['status']}</td>";
		//if($perms['edit_alerts']) 
		echo "<td><a href=\"/admin/editalert/id/${alert['id']}\">Edit</a></td>";
		echo "</tr>";
	}
	?>
	</table>
	</td>
</tr>