<div class="contentBox">
	<?php 
	$columns = 0;
	foreach($clubs as $club)
	{
		$div = $this->load->view('clubOrCaucus', $club, true);
		echo $div;
		$columns++;
		if($columns>1)
		{
			echo "<div style='clear:both'></div>";
			echo "<div style='width:100%;height:3px;background-color:#DDDDDD'></div>";
			$columns = 0;
		}
	}
	?>
</div>

<!-- 
  <table width="95%" border="0" align="center" cellpadding="0" cellspacing="15" style='background-color:white'>
    <tr>
      <td width="50%">
	    <div>
	      	<strong>Hillsborough County Young Democrats</strong>
	    </div>
		<div>Meets 2nd Thursday at 7 pm at Tahitian Inn - 601 S. Dale Mabry, Tampa<br></div>
		<div>
        	<strong>President: Timothy Heberlein </strong>(<a href="mailto:tim_heber@yahoo.com" target="_blank">tim_heber@yahoo.com</a>)
		</div>
			  </td>
		      <td width="50%"><div><strong>Hillsborough County Democratic Women's Club</strong></div>
		        <div>Meets monthly, 1st Mondays, 6:30pm at Mimi's Caf&eacute;, 11702 N. Dale Mabry (Carrollwood) <br>
	            </div>
		        <div>
		          <div><strong>President: Naomi Ryan </strong></div>
		          <div><strong>Website:</strong> <a href="http://hcdwc.org">hcdwc.org</a></div>
              	</div>
              </td>
	        </tr>
		    <tr>
		      <td>
				<div>
					<strong>South Shore Democratic Club</strong>
				</div>
				<div>
					Meets   the 2nd Thursday of each month September-May at 1:30 pm at the South   Shore Regional Library, 15816 Beth Shields Way, Ruskin, FL 
				</div>
		        <div>
		        	<strong>President: Arnie Frigeri</strong> (<a href="mailto:Afrigeri@tampabay.rr.com" target="_blank" title="mailto:Afrigeri@tampabay.rr.com">Afrigeri@tampabay.rr.com</a>)
		        </div>
				<div>
					<strong>Website:</strong> <a href="http://www.southshoredemocraticclub.org">southshoredemocraticclub.org</a>
				</div>
			</td>
			<td>
				<div>
					<strong>East Hillsborough Democratic Club</strong>
				</div>
		        <div>
		          <div>Meets the 2nd Tuesday of each month at 6:30 pm at Giordano's Restaurant, 11310 Causeway Blvd, Brandon.</div>
		          <strong>President: Angie Angel</strong> (<a href="mailto:DemsinBrandon@aol.com">DemsinBrandon@aol.com</a> )<br>
	          <strong>Website:</strong> <a href="http://www.hcdec.org/www.easthillsboroughdems.org">www.easthillsboroughdems.org</a></div></td>
	        </tr>
	        
		    <tr>
		    
		      <td>
		        <div>
		        	<strong>Florida Democratic Lawyers Council</strong>
		        </div>
                <div>
                	<strong>Sharon Samek</strong> (<a href="mailto:julie.flyvirgin@verizon.net" title="mailto:julie.flyvirgin@verizon.net">sharonsamek@gmail.com</a>)
                </div>
		      </td>
		      
		      <td>
		      	<div><strong>Northwest Hillsborough Democratic Club</strong></div>
	            <p>Meets the 4th Tuesday of each month at 6:30 pm<br>
	              <a href="http://www.facebook.com/pages/Northwest-Hillsborough-Democrats/372320953274" target="_blank">Find us on Facebook </a><br>
                </p>
			  </td>
			  
	        </tr>
		    <tr>
		    
		      <td>
		      	<div>
		      		<strong>New Tampa Democratic Club</strong>
		      	</div>
				<div>
					<strong>Organizer: Sharon Samek</strong> (<a href="http://www.hcdec.org/sharonsamek@gmail.com">sharonsamek@gmail.com</a> )
				</div>
				<div>
					<strong>Website: </strong><a href="http://www.newtampadems.com/" target="_blank" title="http://www.newtampadems.com/" onClick="return top.js.OpenExtLink(window,event,this)">www.newtampadems.com</a>
				</div>
              </td>
              
		      <td>
		      	<div>
		      		<strong>Central Tampa Democratic Club</strong>
		      	</div>
				<div>
					Encompassing neighborhoods in <em>East Tampa</em>, <em>Sulphur Springs</em> and <em>Seminole</em><em> Heights</em><em>.</em>
				</div>
				<div>
					<strong>Organizer:</strong> <strong>Kevin Wren</strong> (<a href="http://www.hcdec.org/wren.kevin@gmail.com">wren.kevin@gmail.com</a> )
				</div>
              </td>
	        </tr>
	        
		    <tr>
		      <td>
		      	<div>
		      		<strong>South Tampa Democratic Club</strong>
		      	</div>
				<div>
					<strong>Organizer:</strong> <strong>Jane Gibbons </strong>(<a href="http://www.hcdec.org/gibbjane54@gmail.com">gibbjane54@gmail.com</a> )
				</div>
              </td>
		      <td><strong>Temple Terrace Area Democrats</strong><br>
	          Contact: <strong>Lisa Montelione</strong> at <a href="http://www.hcdec.org/ljmfla@gmail.com">ljmfla@gmail.com</a></td>
	        </tr>
	        
		    <tr>
		      <td>
		      	<div>
		      		<strong>UT Democrats</strong><br>Contact:&nbsp;
				</div>
			  </td>
		      <td>
				  <div>
				  	<strong>Hillsborough County Democratic Black Caucus</strong>
				  </div>
				  <div>
				  	Meets monthly, 3rd Tuesdays, 6:30pm at East Tampa Business &amp; Civic Center - 2814 N 22nd St <br>
				  </div>
		          <div>
		          	<strong>President: Dr. Bruce Miles</strong> (<a href="http://www.hcdec.org/bhmilesdds@verizon.net">bhmilesdds@verizon.net</a> ) or 813.237.3588 
		          </div>
              </td>
	        </tr>
	        
		    <tr>
		      <td>
		      	<div>
		      		<strong>Hillsborough Democratic Hispanic Caucus</strong><br>
					President:  Victor DiMaio, 813-361-1922, <br>
					<a href="mailto:hillsboroughhispanicdems@gmail.com">hillsboroughhispanicdems@gmail.com</a><br>
					Mailing Address: 4925 Independence Parkway Suite 195, Tampa, FL 33634<br>
					Meetings are held the third Thursday of each month at 6pm at:<br>
					La Teresita Restaurant, 3248 W. Columbus Drive, Tampa, FL 33607
				</div>
              </td>
              
		      <td>
		        <div>
		        	<strong>Hillsborough County GLTBA Democratic Caucus</strong>
		        </div>
		        <div>Meets the 2nd Wednesday of every month.  Social time begins at 5:30 PM and the meeting begins at 7:00 PM.  The location is the Blue Dog Bistro, 1600 East 8th Ave in Ybor City. <br>
	              Visit the website at http://www.hcglbtadc.org/ 
	            </div>
		        <div>
		        	<strong>President: Sally Phillips </strong>(<a href="mailto:katlvr952@aol.com">katlvr952@aol.com</a>) 813.382.8172
		        </div>
				</td>
	        </tr>
	        
		    <tr>
		      <td><div></div></td>
		      <td>
				  <div><strong>Hillsborough Democratic Disability Caucus<br>
					</strong>For information and meeting locations, please contact:<br>
					President: Jackie Beiro, <a href="mailto:jdbeiro@gmail.com">jdbeiro@gmail.com</a> , phone: 813-412-6256, cell: 813-466-8767<br>
					P.O. Box 151674, Tampa, FL&nbsp; 33684<br>
				  </div>
	          </td>
	        </tr>
		    <tr>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
        </table>
 -->