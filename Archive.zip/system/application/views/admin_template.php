<?php
	$identityContent = "";
	if(isset($user['id']))
	{
		$identityContent = "<div style='width:200px;font-family:Helvetica,Arial,sans-serif;font-size:9pt;color:white'>";
		if(isset($user['salutation']) && !empty($user['salutation']))
			$identityContent .= "Welcome, {$user['salutation']} &#149; ";
		else
			$identityContent .= "Welcome, {$user['firstName']} {$user['lastName']} &#149; ";
		$identityContent .= "<a style='font-family:Helvetica;font-size:9pt;color:white;text-decoration:none;' href=\"/hcdec/logout\">Logout</a>";
		$identityContent .= "</div>";
	}
	else
	{
		$identityContent = "<div style='width:200px;font-family:Helvetica,Arial,sans-serif;font-size:9pt;color:white'>";
		$identityContent .= "<form method=POST action=/hcdec/login>";
		$identityContent .= "Username: <input type=text name=username size=20><br>";
		$identityContent .= "Password: <input type=password name=password size=20>&nbsp;<button type=submit style='width:60px;font-size:9pt'Log In>Log In</button>";
#		$identityContent = "<a style='font-family:Helvetica;font-size:9pt;color:white;text-decoration:none;' href=\"/hcdec/login\">Member login</a>";
		$identityContent .= "</div>";
	}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>Hillsborough County Democratic Party</title>
	<link rel="stylesheet" media="screen" type="text/css" href="http://test.local/css/test.css" />
	<link rel="stylesheet" media="screen" type="text/css" href="http://test.local/css/site.css" />
	<!-- for JS calendar -->
	<link rel="stylesheet" type="text/css" href="/js/tcal.css" />
	<script type="text/javascript" src="/js/tcal.js"></script> 
</head>
<body style='background-color:black'>

<div class="pageContainer">

	<div class="header">
	
		<div style='width:75%;float:left;align:left'>
			<img src="/images/banner.png">
		</div>
		
		<div style='width:25%;float:left;align:right;text-align:right'>
			<a href="http://eepurl.com/g7pxU"><img src="/images/signupButton.png"></a><br>
			<?= $identityContent ?>
		</div>
		
	</div>
	<?php
		$this->load->model('alerts');
		$alerts = $this->alerts->getCurrentAlerts();
		if(count($alerts)>0)
		{
			$tickerContentArray = array();
			foreach($alerts as $alert) 
			{
				$shortTitle = $alert['short_title'];
				$actionURL = $alert['action_url'];
				$tickerContentArray[] = "<a class=\"tickerLink\" href=\"$actionURL\">$shortTitle</a>";
			}
			$tickerContentHTML = implode(" &#149; ", $tickerContentArray);
			
	 ?>
	<table width=960px border=0 cellpadding=0>
	<tr><td width=100%><span background-color:green'>
	<div ID="TICKER" STYLE="overflow:hidden; background-color:lightblue; margin-bottom:4px; padding-top:0; height:24px;width:960px;"  onmouseover="TICKER_PAUSED=true" onmouseout="TICKER_PAUSED=false">
		<?php echo $tickerContentHTML ?>
	</div></span>
	<?php
		}
	?>
	<script type="text/javascript" src="/js/webticker_lib.js"></script>
	</td></tr>
	</table>
	<div style='height:8px'></div>
	
	<div class="menu">
		<a href="/admin/index" class="menuItem" id="index" title="Home page">Home</a> 
		<a href="/admin/members" class="menuItem" id="aboutus" title="Officers, Committees, Principles and Platform">About Us</a> 
		<a href="/admin/users" class="menuItem" id="candidates">Users</a> 
		<a href="/admin/alerts" class="menuItem" id="officials">Alerts</a> 
		<a href="/admin/clubsandcaucuses" class="menuItem" id="clubsandcaucuses">Clubs &amp; Caucuses</a> 
		<a href="/admin/articles" class="menuItem" id="resources">Newsletter Items</a> 
		<a href="/admin/news" class="menuItem" id="news">News</a> 
		<a href="/admin/volunteers" class="menuItem" id="contactus">Volunteers</a> 
		<a href="/admin/calendar" class="menuItem" id="calendar">Calendar</a> 
	<?php 
		if(isset($user['id']))
		{
		?>
		<a href="/hcdec/myhcdec" class="menuItem" id="myhcdec">My HCDEC</a> 
	<?php
		 } 
		?>
	</div>
	
	<div class="leftColumn">
	<!--{SUBMENU}-->
	</div>
	<div class="contentBoxContainer">
	<div class="mainColumn">
	<?= $content ?>
	</div>
	</div>
	<div class="rightColumn">
	<!--{RIGHTITEMS}-->
	</div>
	<div class="footer">
	<!--{FOOTER}-->
	</div>
	
</div>
</body>
</html>