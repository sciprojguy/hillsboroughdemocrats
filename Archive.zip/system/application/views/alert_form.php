<tr>
	<td colspan=2>
		<form method=POST action="/home/addalert">
			<!--
				Type:		Start:			End:			Status:
				[------v]	[mm/dd/yyyy]	[mm/dd/yyyy]	[-------v]
				
				Title:
				[                                        ]
				
				Description:
				+----------------------------------------+
				|                                        |
				|                                        |
				|                                        |
				|                                        |
				+----------------------------------------+
				
				Action URL:
				[                                        ]
				
				                            [Clear] [Submit]
			  -->
		</form>
	</td>
</tr>