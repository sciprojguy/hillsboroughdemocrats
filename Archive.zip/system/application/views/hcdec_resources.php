<?php
?>
<div class="contentBox" style:'height:500px'>
		  <img src="/images/resources.jpg" width="224" height="41">
		  <table width="100%" border="0">
		    <tr>
		      <td width="49%"><p align="center" valign=top><strong>FEDERAL GOVERNMENT</strong></p>
		        <p align="center">The White House<br>
		          <a class="plainLink" href="http://www.whitehouse.gov/">http://www.whitehouse.gov/</a></p>
		        <p align="center">U.S. Senate<br>
		          <a href="http://www.senate.gov/">http://www.senate.gov/</a></p>
		        <p align="center">U.S. House of  Representatives<br>
		          <a href="http://www.house.gov/">http://www.house.gov/</a></p>
		        <p align="center"><strong>STATE  GOVERNMENT</strong></p>
		        <p align="center">The Florida Senate<br>
		          <a href="http://www.flsenate.gov/">http://www.flsenate.gov/</a></p>
		        <p align="center">The Florida House of  Representatives<br>
		          <a href="http://www.myfloridahouse.gov/">http://www.myfloridahouse.gov/</a></p>
		        <p align="center"><br>
		          <a href="http://www.fladems.com/"></a><strong>OUR  ORGANIZATION</strong></p>
		        <p align="center">Democratic National  Committee<br>
		          <a href="http://www.democrats.org/">http://www.democrats.org/</a></p>
		        <p align="center">Florida Democratic  Party<br>
		          <a href="http://www.fladems.com/">http://www.fladems.com/</a></p></td>
		      <td width="51%" valign=top><p align="center"><strong>LOCAL  GOVERNMENT</strong></p>
		        <p align="center">Hillsborough County  Commission<br>
		          <a href="http://www.hillsboroughcounty.org/bocc/">http://www.hillsboroughcounty.org/bocc/</a></p>
		        <p align="center">Hillsborough County  School Board<br>
		          <a href="http://www.sdhc.k12.fl.us/board/">http://www.sdhc.k12.fl.us/board/</a></p>
		        <p align="center">Hillsborough County  Sheriff<br>
		          <a href="http://www.hcso.tampa.fl.us/">http://www.hcso.tampa.fl.us/</a></p>
		        <p align="center">Hillsborough County  Supervisor of Elections<br>
		          <a href="http://votehillsborough.org/">http://votehillsborough.org/</a></p>
		        <p align="center">Hillsborough County  Property Appraiser<br>
		          <a href="http://www.hcpafl.org/">http://www.hcpafl.org/</a></p>
		        <p align="center">Hillsborough County Tax  Collector<br>
		          <a href="http://www.hillstax.org/">http://www.hillstax.org/</a></p>
		        <p align="center">Thirteenth Judicial  Circuit- Hillsborough County<br>
		          <a href="http://www.fljud13.org">www.fljud13.org</a></p>
	        </tr>
	    </table>
</div>