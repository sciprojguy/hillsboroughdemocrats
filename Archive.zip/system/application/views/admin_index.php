Index page for HCDEC Admin Tool<p>
<a href="/admin/users">Users</a>
<a href="/admin/members">Members</a>
<a href="/admin/roles">Roles</a>