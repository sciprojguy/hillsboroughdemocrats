<!-- this page just lists the users - username, first/middle/last, status, edit link
 
Status	Name (Last, First, Middle)		Phone					(Edit)
Type 	Precinct						Email

-->
<p>Users page for HCDEC Admin Tool<p>
<table border=0 cellpadding=4 width=100%>
<?php
# if($user_roles['add_member']) echo "Add member" link
foreach( $members as $member )
{
	echo "<tr>";
	# type, status, first/middle/last name, precinct, email, phone, edit link
	echo "<td>{$member['type']}<br>{$member['status']}</td>";
	echo "<td><strong>{$member['lastName']}, {$member['middleName']} {$member['firstName']}</strong><br>
	Precinct <strong>{$member['precinct']}</strong></td>";
	echo "<td>Phone: <strong>{$member['phone']}</strong><br>";
	"Email: <strong>{$member['email']}<;strong></td>";
	# if($user_roles['edit_member']) echo "Edit" link
	echo "</tr>";
}
?>
</table>