<?php
class Events extends Model {

	function Events()
	{
		parent::Model();
	}

	function emptyEvent()
	{
		return array(
			'date'=>date('Y-m-d'),
			'start_time'=>'12:00 pm',
			'duration_in_minutes'=>30,
			'title'=>'',
			'description'=>'',
			'location'=>'',
			'author'=>'',
			'status'=>'',
			'contact'=>'',
			'contact_phone'=>'',
			'contact_email'=>'',
			'contact_url'=>'',
			'type'=>''
		);
	}
	
	function validateEvent( $event )
	{
		# a number of required fields here
		$errors = array();
		if(!isset($event['date']) || empty($event['date']))
			$errors['date'] = 'Event must have a date';
		if(!isset($event['start_time']) || empty($event['start_time']))
			$errors['start_time'] = 'Event must have a start time';
		if(!isset($event['duration_in_minutes']) || empty($event['duration_in_minutes']))
			$errors['duration_in_minutes'] = 'Event must have a duration in minutes';
		if(!isset($event['title']) || empty($event['title']))
			$errors['title'] = 'Event must have a title';
		if(!isset($event['contact_phone']) || empty($event['contact_phone']))
			$errors['contact_phone'] = 'Event must have a contact phone#';
		return $errors;
	}
	
	function getUpcomingEvents()
	{
		$results = array();
		$r = $this->db->get('upcomingEvents');
		if($r)
		{
			$results['status'] = 'OK';
			$results['rows'] = $r->result_array();
			$r->free_result();
		}
		else
		{
			$results['status'] = 'DB';
			$results['rows'] = array();
		}
		return $results;
	}
	
	function getUpcomingEventsBetween( $date1, $date2 )
	{
		$this->db->where("date >= '$date1' AND date <= '$date2'");
		$this->db->select(array('id','date','start_time','title'));
		$r = $this->db->get('upcomingEvents');
		if($r)
		{
			$results['status'] = 'OK';
			$results['rows'] = $r->result_array();
			$r->free_result();
		}
		else
		{
			$results['status'] = 'DB';
			$results['rows'] = array();
		}
		return $results;
	}	
	
	function addUpcomingEvent( $event )
	{
		$results = array();
		$errors = $this->validateEvent($event);
		if(count($errors)>0)
		{
			$results['status'] = 'VALIDATION';
			$results['errors'] = $errors;
			return $results;
		}
		
		$event['status'] = 'Submitted';
		$event['status_timestamp'] = date('Y-m-d h:i:s');
		$r = $this->db->insert('upcomingEvents', $event);
		if($r)
		{
			$results['status'] = 'OK';
		}
		else
		{
			$results['status'] = 'DB';
			#$results['message'] = $this->db->error_mesage();
		}
		
		return $results;
	}
	
	# change this to return events as array indexed by day of month
	function getEventsForMonthAndYear( $month, $year )
	{
		$results = array();
		$this->db->select('id,type,date,start_time,title,duration_in_minutes,day(date) as day');
		$this->db->where("month(date)=$month AND year(date)=$year");
		$this->db->order_by('day(date)');
		$r = $this->db->get('upcomingEvents');
		if($r)
		{
			$results['status'] = 'OK';
			$events = array();
			foreach( $r->result_array() as $row )
			{
				$events[$row['day']][] = $row;
			}
			$results['rows'] = $events;
			$r->free_result();
		}
		else
		{
			$results['status'] = 'DB';
			$results['rows'] = array();
			print $this->db->query;
		}
		return $results;
	}
	
	function getEventsForTheNextWeek( $month, $day, $year )
	{
		
	}
	
	function getUpcomingEvent( $id )
	{
		$results = array();
		$r = $this->db->get_where('upcomingEvents', array('id'=>$id));
		if($r)
		{
			$results['status'] = 'OK';
			$results['row'] = $this->row_array();
		}
		else
		{
			$results['status'] = 'DB';
		}
		return $results;
	}
	
	function updateUpcomingEvent( $event, $id )
	{
		$results = array();
		$errors = $this->validateEvent($event);
		if(count($errors)>0)
		{
			$results['status'] = 'VALIDATION';
			$results['errors'] = $errors;
		}

		$this->db->where("id = $id");
		$r = $this->db->update('upcomingEvents', $event );
		if($r)
		{
			
		}
		else
		{
			
		}
		return $results;
	}
	
	function addTagToEvent( $tagName, $eventId )
	{
		$results = array();
		
		# first, see if we already have this event tagged with this tag
		$this->db->select('count(*) as n');
		$r = $this->db->get_where('eventTags', array('tag'=>$tagName, 'eventId'=>$eventId));
		
		if($r)
		{
			# if we do, we're done.
			if($r->num_rows()>0)
			{
				$results['status'] = 'OK';
				$results['message'] = 'Already tagged';
			}
			else
			# if we do not, we add the tag
			{
				$tagValues = array(
					'tag'=>$tagName,
					'eventId'=>$eventId
				);
		
				$r = $this->db->insert('eventTags', $tagValues);
				if($r)
				{
					$results['status'] = 'OK';
					$results['message'] = 'Already tagged';
				}
				else
				{
					$results['status'] = 'DB';
				}
			}
		}
		else
		{
			$results['status'] = 'DB';
		}
		
		return $results;
	}
	
	function removeTagFromEvent( $tagName, $eventId )
	{
		$results = array();
		$this->db->where(array('tag'=>$tagName, 'eventId'=>$eventId));
		$r = $this->db->delete('eventTags');
		if($r)
		{
			$results['status'] = 'OK';
			$results['numrows'] = $this->db->affected_rows();
		}
		else
		{
			$results['status'] = 'DB';
			$results['numrows'] = 0;
		}
		return $results;
	}
	
	function getUpcomingEventsWithTags( $tagNameArray )
	{
	/*
	 * SELECT DISTINCT e.id, e.type, e.title, e.date, e.start_time, e.duration_in_minutes
	 * FROM upcomingEvents e, eventTags t WHERE t.tag IN( $tagNames ) AND t.eventId = e.id AND e.date >= $today;
	 */
	}
	
	function cancelUpcomingEvent( $id )
	{
	}
}