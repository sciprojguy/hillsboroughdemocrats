<?php
class Candidates extends Model {

	function Candidates()
	{
		parent::Model();
	}
	
	function emptyCandidate()
	{
		return array(
			"office"=>0,
			"lastName"=>"",
			"firstName"=>"",
			"middleName"=>"",
			"filed"=>"N",
			"filedDate"=>"",
			"qualified"=>"N",
			"qualifiedDate"=>"",
			"qualifiedHow"=>"",
			"webSite"=>"",
			"email"=>"",
			"contact"=>"",
			"contact_address"=>"",
			"contact_phone"=>"",
			"withdrawn"=>"N",
			"withdrawnDate"=>"",
			"picture"=>""
		);
	}
	
	function validateCandidate($candidate)
	{
		$todaysDate = date('Y-m-d');
		
		$errors = array();

		# validate.  need to also check and see whether
		# candidate already exists - check first, middle and last
		# names and fail on *that*.
		
		if('N' == $candidate['filed'])
			$errors['filed'][] = 'Candidate must have filed.';
		if(!isset($candidate['filedDate']) || empty($candidate['filedDate']))
			$errors['filedDate'][] = 'Date of filing cannot be empty';
		else
		if($todaysDate < $candidate['filedDate'])
			$errors['filedDate'][] = 'Date of filing cannot be in the future';

			
			

		if(!isset($candidate['firstName']) || empty($candidate['firstName']))
			$errors['firstName'][] = 'First name is required';
			
		if(!isset($candidate['lastName']) || empty($candidate['lastName']))
			$errors['lastName'][] = 'Last name is required';
			
		# now look for 
		
		# validation:
		# 1. filed date cannot be invalid
		# 2. first and last name are required
		# 3. first and last name cannot match existing candidate
		# 4. qualified date cannot be invalid
		# 5. qualified date cannot be prior to filed date
		# 6. if withdrawn is 'Y', withdrawn date must not be blank.
		# 7. contact is required
		# 8. phone# is required
		if(!isset($candidate['contact']) || empty($candidate['contact']))
			$errors['candidate'][] = 'Contact is required';
		
		return $errors;
	}
	
	function addCandidate( $candidate )
	{
		$results = array();
		
		$errors = $this->validateCandidate( $candidate );
		if(count($errors)>0)
		{
			$results['status'] = 'VALIDATION';
			$results['errors'] = $errors;
		}
		else
		{
			$fields = $this->db->insert_string($candidate);
			$query = str_replace("INSERT", "INSERT OR REPLACE", $fields);
			#$r = $this->db->insert('candidates', $candidate);
			$r = $this->db->query($query);
			if($r)
			{
				$results['status'] = 'OK';
			}
			else
			{
				$results['status'] = 'DB';
			}
		}
		return $results;
	}
	
	function updateCandidate( $candidate, $candidate_id )
	{
		$results = array();
		
		$errors = $this->validateCandidate( $candidate );
		if(count($errors)>0)
		{
			$results['status'] = 'VALIDATION';
			$results['errors'] = $errors;
		}
		else
		{
			$r = $this->db->update('candidates', $candidate, array('id'=>$candidate_id));
			if($r)
			{
				$results['status'] = 'OK';
			}
			else
			{
				$results['status'] = 'DB';
			}
		}
		return $results;
	}
	
	function getCandidate( $id ) 
	{
		$results = array();
		$this->db->where(array('id'=>$id));
		$r = $this->db->get('candidates');
		if($r)
		{
			$results['status'] = 'OK';
			$rr = $r->result_array();
			$results['row'] = $rr[0];
		}
		else
		{
			$results['status'] = 'DB';
		}
		return $results;
	}
	
	function listActiveCandidates()
	{
		$results = array();
		$this->db->where('(filed="Y" or qualified="Y") AND (withdrawn<>"N")');
		$r = $this->db->get('candidates');
		if($r)
		{
			$results['status'] = 'OK';
			$results['rows'] = $r->result_array();
		}
		else
		{
			$results['status'] = 'DB';
		}
		return $results;
	}
	
	function listCandidatesForOffice( $officeId )
	{
		$results = array();
		$this->db->where("office=$officeId AND (filed='Y' or qualified='Y') AND (withdrawn<>'N')");
		$r = $this->db->get('candidates');
		if($r)
		{
			$results['status'] = 'OK';
			$results['rows'] = $r->result_array();
		}
		else
		{
			$results['status'] = 'DB';
		}
		
		return $results;
	}
	
	function listCandidates()
	{
		$results = array();
		$this->db->select('offices.level, offices.title, firstName, middleName, lastName, picture');
		$this->db->from('candidates');
		$this->db->join('offices', 'candidates.office = offices.id');
		$r = $this->db->get();
		if($r)
		{
			$results['status'] = 'OK';
			$results['rows'] = $r->result_array();
		}
		else
		{
			$results['status'] = 'DB';
		}
		return $results;
	}
	
	function listCandidatesGroupedByOffice()
	{
		
	}
	
	function listCandidatesGroupedByLevel()
	{
		$results = array();
		$this->db->select('offices.level, offices.title, firstName, middleName, lastName, picture');
		$this->db->from('candidates');
		$this->db->order_by('level');
		$this->db->join('offices', 'candidates.office = offices.id');
		$r = $this->db->get();
		if($r)
		{
			$results['status'] = 'OK';
			$candidates = array();
			foreach( $r->result_array() as $row )
			{
				$cur_level = $row['level'];
				$candidates[$cur_level][] = $row;
			}			
			$results['rows'] = $candidates;
		}
		else
		{
			$results['status'] = 'DB';
		}
		return $results;		
	}
}
?>