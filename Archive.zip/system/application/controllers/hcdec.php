<?php
error_reporting(E_ALL);
ini_set("display_errors", 1); 

class Hcdec extends Controller {

	function Hcdec()
	{
		parent::Controller();
		session_start();
	}
		
# main page for the site.
	function index()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();

		$content = $this->load->view('hcdec_index', '', true);
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
# "about us" page
	function aboutus()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
			
		$content = $this->load->view('hcdec_aboutus', '', true);
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
# "candidates" page - lists candidates for office - public
	function candidates()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
			
		$this->load->model('candidates');
		$r = $this->candidates->listCandidatesGroupedByLevel();
		if($r['status'] == 'OK')
		{
			$params = array('candidates'=>$r['rows'], 'user'=>$userInfo);
			$content = $this->load->view('hcdec_candidates.php', $params, true);
		}
		else
		if($r['status'] == 'DB')
		{
			$content = "Our database is not feeling very well.  Please check back later.";
		}
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
# add/edit candidates - "manage_candidates" role required
	function newcandidate()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
		# if user is not logged in, redirect w/message
		if(!isset($userInfo['id']))
		{
			redirect("/hcdec/candidates");
			return;
		}
		/*
		# if user is logged in but does not have role, redirect w/message
		if(!isset($userInfo['roles']['manage_candidates']) ||
			'N' == $userInfo['roles']['manage_candidates'])
		{
			redirect("/hcdec/candidates");
			return;
		}
		*/
		$this->load->model('candidates');
		$candidate = $this->candidates->emptyCandidate();
		
		if("GET" == $_SERVER['REQUEST_METHOD'])
		{
			$this->load->model('offices');
			$r = $this->offices->listoffices();
			
			$params = array('user'=>$userInfo, 'offices'=>$r['rows'], 'candidate'=>$candidate );
			$content = $this->load->view('candidate_form', $params, true);
			$p = array('content'=>$content, 'user'=>$userInfo);
			$this->load->view('public_template.php', $p);
		}
		else
		if("POST" == $_SERVER['REQUEST_METHOD'])
		{
			if(isset($_FILES['picture']))
				$_POST['picture'] = $_FILES['picture']['name'];
			else
				$_POST['picture'] = '';
				
			$results = $this->candidates->addCandidate( $_POST );
			if($results['status'] == 'OK')
			{
				if(1 == count($_FILES))
				{
					$docroot = $_SERVER['DOCUMENT_ROOT'];
					$tmp_name = $_FILES['picture']['tmp_name'];
					$filename = $_FILES['picture']['name'];
					$filedest = "$docroot/images/candidates/$filename";
					echo "tmp name: $tmp_name<br>";
					echo "<br>filename: $filename<br>";
					echo "filename: $filedest<br>";

					echo "<br>moved = copy($tmp_name, $filedest);";
					
					$moved = copy("$tmp_name", "$filedest");
					exit(0);
					if(false == $moved)
					{
						# add flash error message	
					}					
				}				
				redirect( "/hcdec/candidates");
			}
			else
			if($results['status'] == 'VALIDATION')
			{
				# collect errors and present form again
				$candidate = $this->candidates->getCandidate($candidate_id);
				$this->load->model('offices');
				$offices = $this->offices->listoffices();
				
				$params = array('user'=>$userInfo, 
							'offices'=>$offices, 
							'candidate'=>$candidate,
							'errors'=>$results['errors'] );
				$content = $this->load->view('hcdec_candidate_form', $params, true);
				$p = array('content'=>$content, 'user'=>$userInfo);
				$this->load->view('public_template.php', $p);
			}
			else
			{
				# error page with $results
			}			
		}
	}
	
	function editcandidate()
	{
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
		# if user is not logged in, redirect w/message
		if(!isset($userInfo['id']))
		{
			redirect("/hcdec/candidates");
			return;
		}
		
		# if user is logged in but does not have role, redirect w/message
		if(!isset($userInfo['roles']['manage_candidates']) ||
			'N' == $userInfo['roles']['manage_candidates'])
		{
			redirect("/hcdec/candidates");
			return;
		}

		$this->load->model('candidates');
			
		if('GET' == $_SERVER['REQUEST_METHOD'])
		{
			$candidate = $this->candidates->emptyCandidate;
			
			$this->load->model('offices');
			$offices = $this->offices->listoffices();
			
			$params = array('user'=>$userInfo, 'offices'=>$offices, 'candidate'=>$candidate );
			$content = $this->load->view('hcdec_candidate_form', $params, true);
			$p = array('content'=>$content, 'user'=>$userInfo);
			$this->load->view('public_template.php', $p);
		}
		else 
		if('POST' == $_SERVER['REQUEST_METHOD'])
		{
			$candidate_id = $_POST['id'];
			$results = $this->candidates->updateCandidate( $_POST, $candidate_id);
			if($results['status'] == 'OK')
			{
				redirect( "/hcdec/candidates");
			}
			else
			if($results['status'] == 'VALIDATION')
			{
				# collect errors and present form again
				$candidate = $this->candidates->getCandidate($candidate_id);
				$this->load->model('offices');
				$offices = $this->offices->listoffices();
				
				$params = array('user'=>$userInfo, 
							'offices'=>$offices, 
							'candidate'=>$candidate,
							'errors'=>$results['errors'] );
				$content = $this->load->view('hcdec_candidate_form', $params, true);
				$p = array('content'=>$content, 'user'=>$userInfo);
				$this->load->view('public_template.php', $p);
			}
			else
			{
				# error page with $results
			}
		}
	}
	
# "officials" page - lists Democratic elected officials (partisan office)
	function officials()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
		$content = $this->load->view('hcdec_electedofficials', '', true);
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
# add/edit officials - "manage_officials" role needed
	function newofficial()
	{
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
	function editofficial()
	{
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
# lists Clubs and Caucuses
	function clubsandcaucuses()
	{
		$this->load->model('clubs');
		$r = $this->clubs->getClubsAndCaucuses();
		
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
		$params['clubs'] = $r['rows'];	
		$content = $this->load->view('hcdec_clubsandcaucuses', $params, true);
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}

# add/edit clubs or caucuses - "manage_clubs_caucuses" role required
	function newcluborcaucus()
	{
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
	function editcluborcaucus()
	{
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
# lists News
	function news()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
			
		$content = $this->load->view('hcdec_news', '', true);
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
# move to use public template
# Resources - vote by mail, find my precinct, etc.
	function resources()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
				
		$content = $this->load->view('hcdec_resources', '', true);
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
	function editresources()
	{
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
# Contact us - volunteer, etc.
	function contactus()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
				
		$content = $this->load->view('hcdec_contactus', '', true);
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
	function donate()
	{
	}
	
	function volunteer()
	{
		$this->load->model('volunteers');
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
					
		if($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			# present blank form
			$volunteer = $this->volunteers->emptyVolunteer();
			
			$params = array("volunteer"=>$volunteer);
			$content = $this->load->view('hcdec_volunteer', $params, true);
			$p = array('content'=>$content, 'user'=>$userInfo);
			$this->load->view('public_template.php', $p);
		}
		else
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			# write into volunteer db and send email to megan gerkin
			$results = $this->volunteers->addVolunteer($_POST);
			if($results['status']=='OK')
			{
				# redirect to /hcdec/index
				redirect('/hcdec/index');
			}
			else
			if($results['status']=='VALIDATION')
			{
				# reload form with errors displayed
				$errors = $results['errors'];
				$params = array("volunteer"=>$_POST, 'errors'=>$errors);
				$content = $this->load->view('hcdec_volunteer', $params, true);
				$p = array('content'=>$content, 'user'=>$userInfo);
				$this->load->view('public_template.php', $p);
			}
			else
			{
				# redirect to error page
			}
		}
	}
	
# get volunteers - lists volunteers.  "manage_volunteers" role required
# needs sort/filter criteria:
	# "volunteered since" date
	# precinct #
	# city
	# volunteered for (phone bank, candidate support, etc)
	# committee
	# democrat y/n
	# hcdec y/n
	# volunteered before

	function getvolunteers()
	{
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
	function volunteerCSVfile()
	{	
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message			
	}
	
# Upcoming Events
	function calendar()
	{
		if(isset($_SESSION['user']))
			$userInfo = $_SESSION['user'];
		else
			$userInfo = array();
			
		$params = $this->uri->uri_to_assoc(3);
		if(!isset($params['month']) || empty($params['month']))
			$month = date('m');
		else
			$month = $params['month'];
			
		if(!isset($params['year']) || empty($params['year']))
			$year = date('Y');
		else
			$year = $params['year'];
		
		$this->load->model('events');
		$results = $this->events->getEventsForMonthAndYear( $month, $year );
		if($results['status']=='OK')
		{
			$data = array('events'=>$results['rows'], 'month'=>$month, 'year'=>$year);
			$content = $this->load->view('hcdec_calendar', $data, true);
			$p = array('content'=>$content, 'user'=>$userInfo);
		}
		else
		{
			# fetch error page for db			
		}
		
		$this->load->view('public_template.php', $p);
	}
	
	function eventsforweek()
	{
		if(isset($_SESSION['user']))
			$userInfo = $_SESSION['user'];
		else
			$userInfo = array();
			
		$params = $this->uri->uri_to_assoc(3);
		if(!isset($params['month']) || empty($params['month']))
			$month = date('m');
		else
			$month = $params['month'];
			
		if(!isset($params['year']) || empty($params['year']))
			$year = date('Y');
		else
			$year = $params['year'];
		
		if(!isset($params['week']) || empty($params['week']))
			$day = date('d');
		else
			$day = $params['week'];
		
	}
	
	function eventsfordate()
	{
		
	}
	
# approve/reject events - "manage_calendar" role required
	function submittedevents()
	{
		# get list of submitted events - events with status of 'submitted'
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
	function reviewevent()
	{
		# display particular event in a 'review' form.  for now this only
		# has a dropdown for "Approve"/"Disapprove", one for reason, and
		# a textarea for details. 
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
# member login
	function login()
	{
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$username = $_POST['username'];
			$password = $_POST['password'];
			$this->load->model('users');
			$r = $this->users->loginUser($username, $password);
			if($r['status'] == 'OK')
			{
				$uInfo = $r['user'][0];
				$uID = $uInfo['id'];
				$r = $this->users->getUserRoles( $uID );
				if($r['status'] == 'OK')
					$uInfo['roles'] = $r['rows'];
				$_SESSION['user'] = $uInfo;
			}
			redirect('/hcdec/index');
		}
		else 
		{
			# display login form with error message...
		}
	}
	
	function logout()
	{
		session_destroy();
		redirect('/hcdec/index');
	}
	
#member page
	function myhcdec()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
		# get events for the current month/year
		$this->load->model('events');
		$results = $this->events->getEventsForMonthAndYear( date('m'), date('Y'));
		if($results['status']=='OK')
			$events = $results['rows'];
		else 
			$events = array();
		$content = $this->load->view('hcdec_member', array('user'=>$userInfo, 'events'=>$events), true);
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
# administrative links
	function users()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
		$this->load->model('users');
		$results = $this->users->getAllUsers();
		if($results['status'] == 'OK')
		{
			$page_params = array('users'=>$results['rows']);
			$content = $this->load->view('admin_users', $page_params, true);
		}
		else
		{
			$content = "Unable to get list of users just now";
		}
		
		$p = array('content'=>$content, 'user'=>$userInfo);
		$this->load->view('public_template.php', $p);
	}
	
	function edituser()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
		if($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$params = $this->uri->uri_to_assoc(3);
			# look up user for $params['mid']
			$this->load->view('admin_header');
			$this->load->view('admin_activateuserform');
			$this->load->view('admin_footer');
		}
		else
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			# try to update user using $_POST
			# if okay, redirect to '/admin/users'
			# if not okay, reload form with error messages
			$this->load->view('admin_header');
			$this->load->view('admin_activateuserform');
			$this->load->view('admin_footer');
		}
	}
	
#member management
	function members()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# member directory - public, but if user has "manage_members" role
		# there is an "Add Member" link at the top and an "Edit" button next
		# to each member row in the page.
		
		# directory should be sortable by name, type and precinct#
		# and searchable?
	}
	
	function addmember()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
		# admin_header
		# admin_member_form
		# admin_footer
	}
	
	function editmember()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
		$params = $this->uri->uri_to_assoc(3);
		# admin_header
		# admin_member_form
		# admin_footer
	}
	
# role management
	function roles()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
	function addrole()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}
	
	function editrole()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
		$params = $this->uri->uri_to_assoc(3);
	}
	
	function deleterole()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		$params = $this->uri->uri_to_assoc(3);
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
	}	
	
# Action Alerts
	function alerts()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();		
		$this->load->model('alerts');
		$alerts = $this->alerts->getNewAndActiveAlerts();
		$p = array('alerts'=>$alerts);		
		$content = $this->load->view('hcdec_alerts', $p, true);
		$b = array('content'=>$content);
		$this->load->view('public_template', $b);
	}
	
	# note - these need to go into the admin controller
	function addalert()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
		$this->load->model('alerts');
		if($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$header_params = array('page'=>'addalert');
			$this->load->view('hcdec_header', $header_params);
			
			$alert = $this->alerts->emptyAlert();
			$form_params = array('page'=>'addalert', 
				'button' => 'Add',
				'alert'=>$alert, 
				'action'=>'/hcdec/addalert');
			$this->load->view('hcdec_alert_form', $form_params);
			$this->load->view('hcdec_footer');
		}
		else
		{
			$r = $this->alerts->addAlert( $_POST );
			if($r['status'] == 'OK')
				redirect('/hcdec/alerts');
			else
			if($r['status'] == 'VALIDATION')
			{
				$header_params = array('page'=>'addalert');
				$this->load->view('hcdec_header', $header_params);
				
				$form_params = array(
						'page'=>'addalert', 
						'button' => 'Add',
						'errors'=>$r['errors'],
						'alert'=>$_POST,
						'action'=>'/hcdec/addalert'
				);
				$this->load->view('hcdec_alert_form', $form_params);
				$this->load->view('hcdec_footer');
			}
			else
			if($r['status'] == 'DB')
			{
				# display error page
			}
			else
			{
				# display error page
			}
		}
	}
	
	function editalert()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
		if($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$id = -1;
			$parms = $this->uri->uri_to_assoc(3);
			if(isset($parms['id'])) $id = $parms['id'];
			$this->load->model('alerts');
			$r = $this->alerts->getAlertForId($id);
			if($r['status'] == 'OK')
			{
				$header_params = array('page'=>'editalert');
				$this->load->view('hcdec_header', $header_params);
				if(!isset($r['errors'])) $r['errors'] = array();
				$form_params = array(
						'page'=>'editalert', 
						'id'=>$id,
						'button' => 'Apply',
						'errors'=>$r['errors'],
						'alert'=>$r['rows'][0],
						'action'=>'/hcdec/editalert'
				);
				$this->load->view('hcdec_alert_form', $form_params);
				$this->load->view('hcdec_footer');
			}
			else
			{
			}
		}
		else
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
				$this->load->model('alerts');
				$r = $this->alerts->setAlertInfo( $_POST, $_POST['id'] );
				//var_dump($r);
				redirect('/hcdec/alerts');
		}
	}
	
	function deletealert()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		# if user is not logged in, redirect w/message
		# if user is logged in but does not have role, redirect w/message
		if($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			# display confirmation page
		}
		else
		{
			# delete alert and redirect to /home/alerts
		}
	}
	
# manage resources	
	function addresource()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
	}
	
	function editresource()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
	}

# newsletter articles
	function articles()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
	}
	
	function viewarticle()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		
	}
	
	# available to all members
	function submitarticle()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		if($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			
		}	
		else
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			
		}	
	}
	
	# only available to users with "edit_newsletter" role
	function reviewarticle()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		if($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			
		}	
		else
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			
		}	
	}
	
	function submitevent()
	{
		if(isset($_SESSION['user'])) $userInfo = $_SESSION['user'];
		else $userInfo = array();
		if($_SERVER['REQUEST_METHOD'] == 'GET')
		{
			$this->load->model('events');
			$event = $this->events->emptyEvent();
			$content = $this->load->view('submit_event', array('user'=>$userInfo,'event'=>$event), true);
			$p = array('content'=>$content, 'user'=>$userInfo);
			$this->load->view('public_template.php', $p);			
		}	
		else
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$this->load->model('events');
			$results = $this->events->addUpcomingEvent( $_POST );
			if($results['status']=='OK')
			{
				redirect('/hcdec/myhcdec');
			}
			else
			{
				$errors = $results['errors'];
				$content = $this->load->view('submit_event', array('user'=>$userInfo,'event'=>$event, 'errors'=>$errors), true);
				$p = array('content'=>$content, 'user'=>$userInfo);
				$this->load->view('public_template.php', $p);			
			}
		}	
	}
}

/* End of file hcdec.php */
/* Location: ./system/application/controllers/hcdec.php */